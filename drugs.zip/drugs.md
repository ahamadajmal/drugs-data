```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
df=pd.read_csv("C:/Users/Peer/Desktop/kaggle/drugs.csv")
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>n</th>
      <th>alcohol-use</th>
      <th>alcohol-frequency</th>
      <th>marijuanause</th>
      <th>marijuana-frequency</th>
      <th>cocaine-use</th>
      <th>cocaine-frequency</th>
      <th>crack-use</th>
      <th>crack-frequency</th>
      <th>...</th>
      <th>oxycontin-use</th>
      <th>oxycontin-frequency</th>
      <th>tranquilizer-use</th>
      <th>tranquilizer-frequency</th>
      <th>stimulant-use</th>
      <th>stimulant-frequency</th>
      <th>meth-use</th>
      <th>meth-frequency</th>
      <th>sedative-use</th>
      <th>sedative-frequency</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>12</td>
      <td>2798</td>
      <td>3.9</td>
      <td>3</td>
      <td>1.1</td>
      <td>4</td>
      <td>0.1</td>
      <td>5</td>
      <td>0.0</td>
      <td>-</td>
      <td>...</td>
      <td>0.1</td>
      <td>24.5</td>
      <td>0.2</td>
      <td>52.0</td>
      <td>0.2</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>-</td>
      <td>0.2</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>13</td>
      <td>2757</td>
      <td>8.5</td>
      <td>6</td>
      <td>3.4</td>
      <td>15</td>
      <td>0.1</td>
      <td>1</td>
      <td>0.0</td>
      <td>3</td>
      <td>...</td>
      <td>0.1</td>
      <td>41</td>
      <td>0.3</td>
      <td>25.5</td>
      <td>0.3</td>
      <td>4.0</td>
      <td>0.1</td>
      <td>5</td>
      <td>0.1</td>
      <td>19.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>14</td>
      <td>2792</td>
      <td>18.1</td>
      <td>5</td>
      <td>8.7</td>
      <td>24</td>
      <td>0.1</td>
      <td>5.5</td>
      <td>0.0</td>
      <td>-</td>
      <td>...</td>
      <td>0.4</td>
      <td>4.5</td>
      <td>0.9</td>
      <td>5.0</td>
      <td>0.8</td>
      <td>12.0</td>
      <td>0.1</td>
      <td>24</td>
      <td>0.2</td>
      <td>16.5</td>
    </tr>
    <tr>
      <th>3</th>
      <td>15</td>
      <td>2956</td>
      <td>29.2</td>
      <td>6</td>
      <td>14.5</td>
      <td>25</td>
      <td>0.5</td>
      <td>4</td>
      <td>0.1</td>
      <td>9.5</td>
      <td>...</td>
      <td>0.8</td>
      <td>3</td>
      <td>2.0</td>
      <td>4.5</td>
      <td>1.5</td>
      <td>6.0</td>
      <td>0.3</td>
      <td>10.5</td>
      <td>0.4</td>
      <td>30.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>16</td>
      <td>3058</td>
      <td>40.1</td>
      <td>10</td>
      <td>22.5</td>
      <td>30</td>
      <td>1.0</td>
      <td>7</td>
      <td>0.0</td>
      <td>1</td>
      <td>...</td>
      <td>1.1</td>
      <td>4</td>
      <td>2.4</td>
      <td>11.0</td>
      <td>1.8</td>
      <td>9.5</td>
      <td>0.3</td>
      <td>36</td>
      <td>0.2</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>17</td>
      <td>3038</td>
      <td>49.3</td>
      <td>13</td>
      <td>28.0</td>
      <td>36</td>
      <td>2.0</td>
      <td>5</td>
      <td>0.1</td>
      <td>21</td>
      <td>...</td>
      <td>1.4</td>
      <td>6</td>
      <td>3.5</td>
      <td>7.0</td>
      <td>2.8</td>
      <td>9.0</td>
      <td>0.6</td>
      <td>48</td>
      <td>0.5</td>
      <td>6.5</td>
    </tr>
    <tr>
      <th>6</th>
      <td>18</td>
      <td>2469</td>
      <td>58.7</td>
      <td>24</td>
      <td>33.7</td>
      <td>52</td>
      <td>3.2</td>
      <td>5</td>
      <td>0.4</td>
      <td>10</td>
      <td>...</td>
      <td>1.7</td>
      <td>7</td>
      <td>4.9</td>
      <td>12.0</td>
      <td>3.0</td>
      <td>8.0</td>
      <td>0.5</td>
      <td>12</td>
      <td>0.4</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>19</td>
      <td>2223</td>
      <td>64.6</td>
      <td>36</td>
      <td>33.4</td>
      <td>60</td>
      <td>4.1</td>
      <td>5.5</td>
      <td>0.5</td>
      <td>2</td>
      <td>...</td>
      <td>1.5</td>
      <td>7.5</td>
      <td>4.2</td>
      <td>4.5</td>
      <td>3.3</td>
      <td>6.0</td>
      <td>0.4</td>
      <td>105</td>
      <td>0.3</td>
      <td>6.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>20</td>
      <td>2271</td>
      <td>69.7</td>
      <td>48</td>
      <td>34.0</td>
      <td>60</td>
      <td>4.9</td>
      <td>8</td>
      <td>0.6</td>
      <td>5</td>
      <td>...</td>
      <td>1.7</td>
      <td>12</td>
      <td>5.4</td>
      <td>10.0</td>
      <td>4.0</td>
      <td>12.0</td>
      <td>0.9</td>
      <td>12</td>
      <td>0.5</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>21</td>
      <td>2354</td>
      <td>83.2</td>
      <td>52</td>
      <td>33.0</td>
      <td>52</td>
      <td>4.8</td>
      <td>5</td>
      <td>0.5</td>
      <td>17</td>
      <td>...</td>
      <td>1.3</td>
      <td>13.5</td>
      <td>3.9</td>
      <td>7.0</td>
      <td>4.1</td>
      <td>10.0</td>
      <td>0.6</td>
      <td>2</td>
      <td>0.3</td>
      <td>9.0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>22</td>
      <td>4707</td>
      <td>84.2</td>
      <td>52</td>
      <td>28.4</td>
      <td>52</td>
      <td>4.5</td>
      <td>5</td>
      <td>0.5</td>
      <td>5</td>
      <td>...</td>
      <td>1.7</td>
      <td>17.5</td>
      <td>4.4</td>
      <td>12.0</td>
      <td>3.6</td>
      <td>10.0</td>
      <td>0.6</td>
      <td>46</td>
      <td>0.2</td>
      <td>52.0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>23</td>
      <td>4591</td>
      <td>83.1</td>
      <td>52</td>
      <td>24.9</td>
      <td>60</td>
      <td>4.0</td>
      <td>6</td>
      <td>0.5</td>
      <td>6</td>
      <td>...</td>
      <td>1.3</td>
      <td>20</td>
      <td>4.3</td>
      <td>10.0</td>
      <td>2.6</td>
      <td>10.0</td>
      <td>0.7</td>
      <td>21</td>
      <td>0.2</td>
      <td>17.5</td>
    </tr>
    <tr>
      <th>12</th>
      <td>24</td>
      <td>2628</td>
      <td>80.7</td>
      <td>52</td>
      <td>20.8</td>
      <td>52</td>
      <td>3.2</td>
      <td>5</td>
      <td>0.4</td>
      <td>6</td>
      <td>...</td>
      <td>1.2</td>
      <td>13.5</td>
      <td>4.2</td>
      <td>10.0</td>
      <td>2.3</td>
      <td>7.0</td>
      <td>0.6</td>
      <td>30</td>
      <td>0.4</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>25</td>
      <td>2864</td>
      <td>77.5</td>
      <td>52</td>
      <td>16.4</td>
      <td>72</td>
      <td>2.1</td>
      <td>8</td>
      <td>0.5</td>
      <td>15</td>
      <td>...</td>
      <td>0.9</td>
      <td>46</td>
      <td>3.6</td>
      <td>8.0</td>
      <td>1.4</td>
      <td>12.0</td>
      <td>0.4</td>
      <td>54</td>
      <td>0.4</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>26</td>
      <td>7391</td>
      <td>75.0</td>
      <td>52</td>
      <td>10.4</td>
      <td>48</td>
      <td>1.5</td>
      <td>15</td>
      <td>0.5</td>
      <td>48</td>
      <td>...</td>
      <td>0.3</td>
      <td>12</td>
      <td>1.9</td>
      <td>6.0</td>
      <td>0.6</td>
      <td>24.0</td>
      <td>0.2</td>
      <td>104</td>
      <td>0.3</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>27</td>
      <td>3923</td>
      <td>67.2</td>
      <td>52</td>
      <td>7.3</td>
      <td>52</td>
      <td>0.9</td>
      <td>36</td>
      <td>0.4</td>
      <td>62</td>
      <td>...</td>
      <td>0.4</td>
      <td>5</td>
      <td>1.4</td>
      <td>10.0</td>
      <td>0.3</td>
      <td>24.0</td>
      <td>0.2</td>
      <td>30</td>
      <td>0.2</td>
      <td>104.0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>28</td>
      <td>2448</td>
      <td>49.3</td>
      <td>52</td>
      <td>1.2</td>
      <td>36</td>
      <td>0.0</td>
      <td>-</td>
      <td>0.0</td>
      <td>-</td>
      <td>...</td>
      <td>0.0</td>
      <td>-</td>
      <td>0.2</td>
      <td>5.0</td>
      <td>0.0</td>
      <td>364.0</td>
      <td>0.0</td>
      <td>-</td>
      <td>0.0</td>
      <td>15.0</td>
    </tr>
  </tbody>
</table>
<p>17 rows × 28 columns</p>
</div>




```python
plt.hist(df['marijuanause'])
```




    (array([3., 1., 2., 0., 2., 1., 1., 1., 2., 4.]),
     array([ 1.1 ,  4.39,  7.68, 10.97, 14.26, 17.55, 20.84, 24.13, 27.42,
            30.71, 34.  ]),
     <BarContainer object of 10 artists>)




    
![png](output_2_1.png)
    



```python
sns.jointplot('age','marijuanause',df,color='r')
plt.show
```

    C:\Users\Peer\anaconda3\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variables as keyword args: x, y, data. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    




    <function matplotlib.pyplot.show(close=None, block=None)>




    
![png](output_3_2.png)
    



```python
sns.jointplot('age','meth-use',df,color='g')
```




    <seaborn.axisgrid.JointGrid at 0x23943564370>




    
![png](output_4_1.png)
    



```python
plt.subplot(321)
plt.title("alcohol-use")
sns.distplot(df['alcohol-use'],hist=False)

plt.subplot(322)
plt.title("marijuana-use")
sns.distplot(df['marijuanause'],hist=False)

plt.subplot(323)
plt.title("cocaine-use")
sns.distplot(df['cocaine-use'],hist=False)

plt.subplot(324)
plt.title("crack-use")
sns.distplot(df['crack-use'],hist=False)

plt.subplot(325)
plt.title('sedative-use')
sns.distplot(df['sedative-use'],hist=False)

plt.subplot(326)
plt.title("meth-use")
sns.distplot(df['meth-use'],hist=False)

plt.show()
```

    C:\Users\Peer\anaconda3\lib\site-packages\seaborn\distributions.py:2551: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `kdeplot` (an axes-level function for kernel density plots).
      warnings.warn(msg, FutureWarning)
    C:\Users\Peer\anaconda3\lib\site-packages\seaborn\distributions.py:2551: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `kdeplot` (an axes-level function for kernel density plots).
      warnings.warn(msg, FutureWarning)
    C:\Users\Peer\anaconda3\lib\site-packages\seaborn\distributions.py:2551: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `kdeplot` (an axes-level function for kernel density plots).
      warnings.warn(msg, FutureWarning)
    C:\Users\Peer\anaconda3\lib\site-packages\seaborn\distributions.py:2551: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `kdeplot` (an axes-level function for kernel density plots).
      warnings.warn(msg, FutureWarning)
    C:\Users\Peer\anaconda3\lib\site-packages\seaborn\distributions.py:2551: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `kdeplot` (an axes-level function for kernel density plots).
      warnings.warn(msg, FutureWarning)
    C:\Users\Peer\anaconda3\lib\site-packages\seaborn\distributions.py:2551: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `kdeplot` (an axes-level function for kernel density plots).
      warnings.warn(msg, FutureWarning)
    


    
![png](output_5_1.png)
    



```python
sns.countplot(df['alcohol-use'])
```

    C:\Users\Peer\anaconda3\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variable as a keyword arg: x. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    




    <AxesSubplot:xlabel='alcohol-use', ylabel='count'>




    
![png](output_6_2.png)
    



```python

```
